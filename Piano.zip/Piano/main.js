// all keys
const keys = document.querySelectorAll(".key");

function setKey(event){

    console.log(event.keyCode);

    const datakey = verifyEventType(event);
    const audio = document.querySelector(`audio[data-key="${datakey}"]`);

    const divKey = document.querySelector(`.key[data-key="${datakey}"]`);

    addAnimation(divKey);
    playSong(audio);
}

// verify event type
function verifyEventType(event){
    let key;

    event.type === 'click' ? key = event.target.dataset.key:key = event.keyCode;

    return key;
}

// play audio
function playSong(audio){
    audio.currentTime = 0;
    audio.play();
}

// add animation
function addAnimation(divKey){
    if(divKey.classList.contains('white-key')){
        divKey.classList.add('movekeyWhite');
        removeAnimation(divKey, 'movekeyWhite');
    }else if(divKey.classList.contains('black-key')){
        divKey.classList.add('movekeyBlack');
        removeAnimation(divKey, 'movekeyBlack');
    }else{
        alert("Erro!");
    }
}

// remove animation
function removeAnimation(divKey, className){
    divKey.addEventListener("animationend", () => {
        divKey.classList.remove(className);
    });
}
// click event 
keys.forEach(key => {
    key.addEventListener("click", setKey);
});
// event of keyboard
document.addEventListener("keydown", setKey);
